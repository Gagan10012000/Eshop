from store.middleware.auth import auth_middleware
from store.views.order import Orderview
from store.views.checkout import Checkout
from django.urls import path
from store.views import home,login,signup,cart


urlpatterns = [
    path('',home.Index.as_view()),
    path('signup',signup.Signup.as_view()),
    path('login',login.Login.as_view()),
    path('logout',login.logout),
    path('cart',cart.Cart.as_view()),
    path("checkout",Checkout.as_view()),
    path("order", auth_middleware(Orderview.as_view()))
]
#new@name=12345