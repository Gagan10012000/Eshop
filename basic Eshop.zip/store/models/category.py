from django.db import models
from django.db.models.fields import CharField

class Category(models.Model):
    name=models.CharField(max_length=60)

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

    def __str__(self):
        return self.name