from store.models.category import Category
from django.db import models
from django.db.models.fields import CharField

class Product(models.Model):
    name=models.CharField(max_length=80)
    price=models.IntegerField(default=0)
    desc=models.CharField(max_length=120)
    cat=models.ForeignKey(Category,on_delete=models.CASCADE,default=1)
    image=models.ImageField(upload_to='uploads/products/')

    @staticmethod
    def get_products_by_id(ids):
        return Product.objects.filter(id__in=ids)
    
    
    @staticmethod
    def get_all_products():
        return Product.objects.all()

    @staticmethod
    def get_all_products_by_categoryid(cat_id):
        if cat_id:
            return Product.objects.filter(cat=cat_id)
        else:
            return Product.get_all_products()
