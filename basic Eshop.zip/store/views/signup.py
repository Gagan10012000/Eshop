from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.shortcuts import redirect, render
from django.views import View


class Signup(View):
    def validatecustomer(self,customer):
        error_message = None
        if not customer.first_name:
            error_message = "First Name Required !!"
        elif not customer.last_name:
            error_message = 'Last Name Required'
        elif not customer.phone:
            error_message = 'Phone Number required'
        elif len(customer.phone) < 10:
            error_message = 'Phone Number must be 10 char Long'
        elif len(customer.password) < 3:
            error_message = 'Password must be 3 char long'
        elif customer.isExists():
            error_message='Email already exists '

        return error_message

    def post(self,request):
        first_name=request.POST.get('firstname')
        last_name=request.POST.get('lastname')
        phone=request.POST.get('phone')
        email=request.POST.get('email')
        password=request.POST.get('password')
        customer=Customer(first_name=first_name,last_name=last_name,
        email=email,password=password,phone=phone)
        value={'first_name':first_name,"last_name":last_name,
        'phone':phone,'email':email}
        
        error_message=self.validatecustomer(customer)
        if not error_message:
            customer.password=make_password(customer.password)
            customer.save()
            return redirect("/")

        else:
            data={'error':error_message,'value':value}
            return render(request,'signup.html',data)

    def get(self,request):
        return render (request,'signup.html')

