from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.shortcuts import redirect, render
from django.views import View


class Login(View):
    def post(self,request):
        email=request.POST.get('email')
        password=request.POST.get('password')
        user=Customer.get_customer_by_email(email)
        error_message=None
        if user:
           flag=check_password(password,user.password)
           if flag:
               request.session['user_id']=user.id
               return redirect("/")
           else:
               error_message='Password incorrect'
        else:
            error_message="Email not registered"
        return render(request,"login.html",{'error':error_message})


    def get(self,request):
        return render(request,'login.html')        
        

def logout(request):
    request.session.clear()
    return redirect('/login')