from store.models.customer import Customer
from store.models.order import Order
from store.models.product import Product
from django.shortcuts import redirect
from django.views import View

class Checkout(View):
    def get(self,request):
        return redirect("/")

    def post(self,request):
        address=request.POST.get('address')
        customer=request.session.get('user_id')
        cart=request.session.get('cart')
        products=Product.get_products_by_id(list(cart.keys()))
        for i in products:
            order=Order(customer = Customer(id = customer),
            product=i,price=i.price,address=address,quantity=cart.get(str(i.id)))
            order.save()
        request.session['cart']={}
        return redirect("/checkout")