from store.models.order import Order
from django.views import View
from django.shortcuts import render

class Orderview(View):
    def get(self,request):
        customer=request.session.get('user_id')
        orders=Order.get_order_by_customer(customer)
        return render(request,"order.html",{"orders":orders})