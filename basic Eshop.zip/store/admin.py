from store.models.order import Order
from store.models.customer import Customer
from django.contrib import admin
from .models.product import Product
from .models.category import Category

# Register your models here.

class AdminProduct(admin.ModelAdmin):
    list_display=['name','price','cat']

class AdminCustomer(admin.ModelAdmin):
    list_display=['first_name','last_name']

admin.site.register(Product,AdminProduct)
admin.site.register(Category)
admin.site.register(Customer)
admin.site.register(Order)